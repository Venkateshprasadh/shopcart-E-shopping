export class Orders {
    constructor(
        public oid:number,
        public pid:number,
        public email:string,
        public price:number,
        public paid:string
        ){}
}