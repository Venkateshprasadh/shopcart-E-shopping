import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppliancesComponent } from './appliances/appliances.component';
import { CartComponent } from './cart/cart.component';
import { ErrorComponent } from './error/error.component';
import { GroceriesComponent } from './groceries/groceries.component';
import { HomeComponent } from './home/home.component';
import { LaptopsComponent } from './laptops/laptops.component';
import { LoginComponent } from './login/login.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentresultComponent } from './paymentresult/paymentresult.component';
import { PreviousordersComponent } from './previousorders/previousorders.component';
import { ProductsComponent } from './products/products.component';
import { RegistrationComponent } from './registration/registration.component';
import { SmartphonesComponent } from './smartphones/smartphones.component';
import { SubscriberComponent } from './subscriber/subscriber.component';
import { ToysComponent } from './toys/toys.component';

const routes: Routes = [
  {path:"", component:LoginComponent},
  {path:"register", component:RegistrationComponent},
  {path:"login", component:LoginComponent},
  {path:"home", component:HomeComponent},
  {path:"products", component:ProductsComponent},
  {path:"smartphones", component:SmartphonesComponent},
  {path:"laptops", component:LaptopsComponent},
  {path:"appliances", component:AppliancesComponent},
  {path:"toys", component:ToysComponent},
  {path:"groceries", component:GroceriesComponent},
  {path:"error", component:ErrorComponent},
  {path:"subscriber", component:SubscriberComponent},
  {path:"cart", component:CartComponent},
  {path:"paymentgateway", component:PaymentComponent},
  {path:"paymentresult", component:PaymentresultComponent},
  {path:"previousorder", component:PreviousordersComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
