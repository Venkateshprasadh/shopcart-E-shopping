import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { products } from './products';
import { ProductsService } from './products.service';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'shopcart';
  product:Array<products>=[];
  searchform=new FormGroup({
    query:new FormControl("",Validators.required),
    
    
  });
 
  constructor(public ps:ProductsService,public router:Router) { }
  ngOnInit(): void {
  }
  search()
  {
    // let login = this.searchform.value;
    // console.log(login);
    // this.us.Loginuser(login).subscribe({
    //   next:(result:any)=>{
    //     if(result=="Login Succesfull")
    //     {
    //       this.router.navigate(['home']);
    //     }
    //     else{
    //       this.msg=result;
    //     }
    //   },
    //   error:(error:any)=>console.log(error),
    //   complete:()=>console.log("completed")

    // })
    let search = this.searchform.value;
    console.log(search.query)
    if(search.query?.toLowerCase()=='smartphones' || search.query?.toLowerCase()=='smartphone' || search.query?.toLowerCase()=='phone' || search.query?.toLowerCase()=='phones' || search.query?.toLowerCase()=='mobiles'|| search.query?.toLowerCase()=='mobile' ||search.query?.toLowerCase()=='cellphones' || search.query?.toLowerCase()=='cellphone')
    {
      this.router.navigate(['smartphones'])
    }
    else if(search.query?.toLowerCase()=='toys' || search.query?.toLowerCase()=='toy')
    {
      this.router.navigate(['toys'])
    }
    else if(search.query?.toLowerCase()=='laptops' || search.query?.toLowerCase()=='lap' || search.query?.toLowerCase()=='laptop')
    {
      this.router.navigate(['laptops'])
    }
    else if(search.query?.toLowerCase()=='groceries' ||search.query?.toLowerCase()=='grocerie' ||search.query?.toLowerCase()=='household'||search.query?.toLowerCase()=='grocery'||search.query?.toLowerCase()=='grocerie'){
      this.router.navigate(['groceries'])
    }
    else if(search.query?.toLowerCase()=='appliances' ||search.query?.toLowerCase()=='appliance'||search.query?.toLowerCase()=='applience'||search.query?.toLowerCase()=='appliences'){
      this.router.navigate(['appliances'])
    }else{
      this.router.navigate(['error'])
    }
    // this.ps.searchProducts(this.search).subscribe({
    //   next:(result:any)=>this.product=result,
    //   error:(error:any)=>console.log(error),
    //   complete:()=>console.log("completed")
    // })
  }
}
