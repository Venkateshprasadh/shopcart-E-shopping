import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProductsComponent } from './products/products.component';
import { SmartphonesComponent } from './smartphones/smartphones.component';
import { LaptopsComponent } from './laptops/laptops.component';
import { AppliancesComponent } from './appliances/appliances.component';
import { ToysComponent } from './toys/toys.component';
import { GroceriesComponent } from './groceries/groceries.component';
import { ErrorComponent } from './error/error.component';
import { SubscriberComponent } from './subscriber/subscriber.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentresultComponent } from './paymentresult/paymentresult.component';
import { PreviousordersComponent } from './previousorders/previousorders.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegistrationComponent,
    LoginComponent,
    ProductsComponent,
    SmartphonesComponent,
    LaptopsComponent,
    AppliancesComponent,
    ToysComponent,
    GroceriesComponent,
    ErrorComponent,
    SubscriberComponent,
    CartComponent,
    PaymentComponent,
    PaymentresultComponent,
    PreviousordersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
