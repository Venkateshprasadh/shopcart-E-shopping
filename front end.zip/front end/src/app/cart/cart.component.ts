import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { products } from '../products';
import { ProductsService } from '../products.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  product:Array<products>=[];
  constructor(public ps:ProductsService,public us:UserService,public router:Router) { }
  search:string='jillu2@gmail.com'
  ngOnInit(): void {
    this.cart()
  }
  cart()
  {
    
    console.log(localStorage.getItem("useremail"))
    this.us.cart(localStorage.getItem("useremail")).subscribe({
      next:(result:any)=>this.product=result,
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    })

  }
  buynow(p:any)
  {
    console.log(p.pid)
    localStorage.setItem("prodid",p.pid)
    localStorage.setItem("prodname",p.pname)
    localStorage.setItem("prodspecification",p.specification)
    localStorage.setItem("prodcategory",p.category)
    localStorage.setItem("prodprice",p.price)
    localStorage.setItem("proddescription",p.description)

    console.log(localStorage.getItem("prodid"))
    this.router.navigate(['paymentgateway'])

  }

}
