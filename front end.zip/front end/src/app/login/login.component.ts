import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit 
{
  loginform=new FormGroup({
    email:new FormControl("",Validators.required),
    password:new FormControl("",Validators.required),
    
  });
  msg:string=""
  
  constructor(public us:UserService,public router:Router) { }

  ngOnInit(): void 
  {
    // this.subscribe()
  }

  // subscribe()
  // {
  //   let useremail=localStorage.getItem("useremail")
  //   this.us.subscribed(useremail).subscribe({
  //     next:(result:any)=>this.subscribed=result,
  //     error:(error:any)=>console.log(error),
  //     complete:()=>console.log("completed")
  //   })
  //   console.log(this.subscribed)

  // }

  login()
  {
    let login = this.loginform.value;
   console.log(login.email)
   
    console.log(login);
    this.us.Loginuser(login).subscribe({
      next:(result:any)=>{
        if(result=="Login Succesfull")
        {
          this.router.navigate(['home']);
          let usermail:string = login.email || '';
          localStorage.setItem("useremail",usermail);
          console.log(localStorage.getItem('useremail'))
          
        }
        else{
          this.msg=result;
        }
      },
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")

    });
   
    

   
  }
  
}
