import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  usermail : string = ""
  productid:any
  amountcheckform=new FormGroup({
    cardno:new FormControl("",Validators.required),
    date:new FormControl("",Validators.required),
    cvvcode:new FormControl("",Validators.required),
    cardname:new FormControl("",Validators.required),
    amount:new FormControl("",Validators.required),
    
    
  });
  prodid:any
  prodname:any
  prodspecification:any
  prodcategory:any
  prodprice:any
  proddescription:any
  constructor(public us:UserService,public router:Router) { }

  ngOnInit(): void 
  {
    console.log(localStorage.getItem("prodid"))
    this.prodid=localStorage.getItem("prodid")
    console.log(localStorage.getItem("prodname"))
    this.prodname=localStorage.getItem("prodname")
    console.log(localStorage.getItem("prodspecification"))
    this.prodspecification=localStorage.getItem("prodspecification")
    console.log(localStorage.getItem("prodcategory"))
    this.prodcategory=localStorage.getItem("prodcategory")
    console.log(localStorage.getItem("prodprice"))
    this.prodprice=localStorage.getItem("prodprice")
    console.log(localStorage.getItem("proddescription"))
    this.proddescription=localStorage.getItem("proddescription")
    let obj = localStorage.getItem("useremail");
    if(obj!=null){
      this.usermail=obj;
    }
    let obj2 = localStorage.getItem("prodid");
    if(obj2!=null){
      this.productid=obj2;
    }
  }
  amountcheck()
  {
    let login = this.amountcheckform.value;
   console.log(login.amount)
   console.log(localStorage.getItem("prodid"))
   console.log(localStorage.getItem("useremail"))
   this.us.buy(this.usermail,this.productid,login.amount).subscribe({
    next:(result:any)=>{
      if(result==="payment succesfull")
      {
        this.router.navigate(['paymentresult']);
        localStorage.removeItem("prodid")
        localStorage.removeItem("prodname")
        localStorage.removeItem("prodspecification")
        localStorage.removeItem("proddescription")
        localStorage.removeItem("prodprice")
      }
      else if((result==="payment failed")){
        this.router.navigate(['error']);
      }
    },
    error:(error:any)=>console.log(error),
    complete:()=>console.log("completed")

  });

  }

  
 

}
