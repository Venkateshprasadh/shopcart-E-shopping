import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-paymentresult',
  templateUrl: './paymentresult.component.html',
  styleUrls: ['./paymentresult.component.css']
})
export class PaymentresultComponent implements OnInit {

 
  constructor(public router:Router) { }

  ngOnInit(): void 
  {
    setTimeout(() => {
      this.router.navigate(['home']);
  }, 5000); 
  }
  

}
