import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Orders } from '../Orders';
import { products } from '../products';
import { ProductsService } from '../products.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-previousorders',
  templateUrl: './previousorders.component.html',
  styleUrls: ['./previousorders.component.css']
})
export class PreviousordersComponent implements OnInit {

  product:Array<products>=[];
  gotocartbutton!:boolean
  showorder!:boolean
  order :Orders=new Orders(0,0,"",0,"")
  subscribed:string=""
  constructor(public ps:ProductsService,public us:UserService,public router:Router) { }

  ngOnInit(): void {
    this.viewproducts()
    
    
  }
  viewproducts()

  {
    console.log(localStorage.getItem("useremail"))
    this.us.previousorders(localStorage.getItem("useremail")).subscribe({
      next:(result:any)=>this.product=result,
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    });
    this.us.subscribed(localStorage.getItem("useremail")).subscribe({
      next:(result:any)=>{
        if(result=="yes")
        {
         
          localStorage.setItem("subscriber",result);
          console.log(localStorage.getItem('subscriber'))
          console.log('jijiji')
          
        }
        else{
          localStorage.setItem("subscriber",result);
          console.log(localStorage.getItem('subscriber'))
        }
        
      },
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    });
    

  }

}
