import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { products } from './products';
@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  baseUrl:string ="http://localhost:9999/product";
  constructor(public http:HttpClient){ }
  saveproduct (products:any):Observable <string> {
    return this.http.post(this.baseUrl+ "/newproduct",products,{responseType:"text"});
  }
  getallproducts():Observable<products[]> {
         return this.http.get<products[]>(this.baseUrl+"/viewproducts");
     }
     searchProducts(search:any):Observable<products[]> {
           return this.http.get<products[]>(this.baseUrl+"/search?query="+search);
       }

}
