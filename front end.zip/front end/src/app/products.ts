export class products {
    constructor( 
        public pid: number,
       public pname: string,
       public specification:string,
       public description: string,
       public category:string,
       public price:number,
       public url:string,
       
        
        
        ){

    }
}