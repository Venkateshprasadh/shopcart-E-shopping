import { devOnlyGuardedExpression } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { products } from '../products';
import { ProductsService } from '../products.service';
import { UserService } from '../user.service';
import {Orders } from '../Orders';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit  {
  product:Array<products>=[];
  gotocartbutton!:boolean
  showorder!:boolean
  order :Orders=new Orders(0,0,"",0,"")
  subscribed:string=""
  constructor(public ps:ProductsService,public us:UserService,public router:Router) { }

  ngOnInit(): void {
    this.viewproducts()
    
    
  }
  viewproducts()
  {console.log(localStorage.getItem("useremail"))
    this.ps.getallproducts().subscribe({
      next:(result:any)=>this.product=result,
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    });
    this.us.subscribed(localStorage.getItem("useremail")).subscribe({
      next:(result:any)=>{
        if(result=="yes")
        {
         
          localStorage.setItem("subscriber",result);
          console.log(localStorage.getItem('subscriber'))
          console.log('jijiji')
          
        }
        else{
          localStorage.setItem("subscriber",result);
          console.log(localStorage.getItem('subscriber'))
        }
        
      },
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    });
    

  }
  buynow(p:any)
  {
   this.placeorder(p)
   this.router.navigate(['cart'])
   this.gotocartbutton=true
   this.showorder=false

  }
  gotocart()
  {
    this.router.navigate(['cart'])
  }
  placeorder(p:any)
  {
    this.gotocartbutton=false
    console.log(p.pid)
   localStorage.setItem("prodid",p.pid)
   let productid=localStorage.getItem("prodid")
   console.log(productid)
   let uemail:any=localStorage.getItem("useremail")
   console.log(uemail)
    this.order.pid=p.pid
    this.order.email=uemail
    this.us.placeorder(this.order).subscribe({
      next:(result:any)=>{
        if(result=="order placed")
        {
          window.alert("added to cart")
         }
        else{
         window.alert("error occured")
        }
      },
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")

    });

  }

}
