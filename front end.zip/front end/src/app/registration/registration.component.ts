import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerform=new FormGroup({
    email:new FormControl("",Validators.required),
    password:new FormControl("",Validators.required),
    subscription:new FormControl("",Validators.required)
    
  });
  msg:string=""
  constructor(public us:UserService,public router:Router) { }

  ngOnInit(): void {
  }
  register()
  {
    let register = this.registerform.value;
    console.log(register);
    this.us.Registeruser(register).subscribe({
      next:(result:any)=>{
        if(result=="Registered succesfully")
        {
          this.router.navigate(['subscriber']);
        }
        else{
          this.msg=result;
        }
      },
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")

    })
  }

  subscribed()
  {
    console.log(localStorage.getItem("useremail"))
    let useremail=localStorage.getItem("useremail")
   this.us.subscribed(useremail).subscribe({
     next:(result2:any)=>{
      if(result2=="yes")
      {
        this.router.navigate(['login'])
      }
     },
     error:(error:any)=>console.log(error),
     complete:()=>console.log("completed")
   })
   console.log(this.subscribed)
  }

}
