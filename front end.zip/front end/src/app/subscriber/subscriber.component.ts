import { Component, OnInit } from '@angular/core';
import { products } from '../products';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-subscriber',
  templateUrl: './subscriber.component.html',
  styleUrls: ['./subscriber.component.css']
})
export class SubscriberComponent implements OnInit {

  product:Array<products>=[];
  constructor(public ps:ProductsService) { }

  ngOnInit(): void {
    this.viewproducts()
  }
  viewproducts()
  {
    this.ps.getallproducts().subscribe({
      next:(result:any)=>this.product=result,
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    })

  }

}
