import { Component, OnInit } from '@angular/core';
import { products } from '../products';
import { ProductsService } from '../products.service';
import {Orders } from '../Orders';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-toys',
  templateUrl: './toys.component.html',
  styleUrls: ['./toys.component.css']
})
export class ToysComponent implements OnInit {
  gotocartbutton!:boolean
  showorder!:boolean
  order :Orders=new Orders(0,0,"",0,"")
  product:Array<products>=[];
  constructor(public ps:ProductsService,public us:UserService,public router:Router) { }
  search:string='toys'
  ngOnInit(): void {
    this.viewtoys()
  }
  viewtoys()
  {
    this.ps.searchProducts(this.search).subscribe({
      next:(result:any)=>this.product=result,
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    })

  }
  buynow(p:any)
  {
   this.placeorder(p)
   this.router.navigate(['cart'])
   this.gotocartbutton=true
   this.showorder=false

  }
  placeorder(p:any)
  {
    this.gotocartbutton=false
    console.log(p.pid)
   localStorage.setItem("prodid",p.pid)
   let productid=localStorage.getItem("prodid")
   console.log(productid)
   let uemail:any=localStorage.getItem("useremail")
   console.log(uemail)
    this.order.pid=p.pid
    this.order.email=uemail
    this.us.placeorder(this.order).subscribe({
      next:(result:any)=>{
        if(result=="order placed")
        {
          window.alert("added to cart")
         }
        else{
         window.alert("error occured")
        }
      },
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")

    });

  }

}
