import { Injectable } from '@angular/core';
import { user } from './user';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { products } from './products';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl:string ="http://localhost:9999/user";
  constructor(public http:HttpClient){ }

  Registeruser (user:any):Observable <string> {
    return this.http.post(this.baseUrl+ "/SignUp",user,{responseType:"text"});
  }

  Loginuser (user:any):Observable <string> {
    return this.http.post(this.baseUrl+ "/SignIn",user,{responseType:"text"});
  }
  cart(email:any):Observable<products[]> {
    return this.http.get<products[]>(this.baseUrl+"/cart?email="+email);
}
searchProducts(search:any):Observable<products[]> {
  return this.http.post<products[]>(this.baseUrl+"/search?query="+search,search);
}
buy(email:any,pid:any,price:any):Observable<any> {
  return this.http.get(this.baseUrl+"/buynow/"+email+"/"+pid+"/"+price,{responseType: 'text'});
}
placeorder(order:any):Observable<string> {
  return this.http.post(this.baseUrl+"/PlaceOrder/",order,{responseType:"text"});
}
previousorders(email:any):Observable<products[]> {
  return this.http.get<products[]>(this.baseUrl+"/previousorders/"+email);
}

// @GetMapping(value = "previousorders/{email}",consumes = MediaType.APPLICATION_JSON_VALUE)
// 	public List<Product> orders(@PathVariable("email") String email)
// 	{
// 		return os.orders(email);
// 	}

// @PostMapping(value = "PlaceOrder",consumes = MediaType.APPLICATION_JSON_VALUE)
// 	public String placeorder(@RequestBody Orders order)
// 	{
// 		return os.placeorder(order);
// 	}
// @GetMapping(value = "buynow/{email}/{pid}/{price}",consumes = MediaType.APPLICATION_JSON_VALUE)
// 	public String buy(@PathVariable("email")  String email,@PathVariable("pid") int pid,@PathVariable("price")  int price)
// 	{
// 		return os.buynow(email, pid, price);
// 	}


  subscribed(email:any):Observable<string>{

    return this.http.post<string>(this.baseUrl+"/subscribed?email="+email,email);
  }
  
// applyjob(doctor:any):Observable<string> {
//     return this.http.post(this.baseUrl+"/sdd",doctor,{responseType:"text"});
//   }
// findPatient(did:any):Observable<Patient[]> {
//     return this.http.get<Patient[]>(this.baseUrl+"/vap/"+did);
// }
// deletePatientById(patient:any):Observable <string> {
//   return this.http.patch(this.baseUrl+"/ups",patient,{responseType:"text"});
// }
// findAppointment(did:any):Observable<Patient[]> {
//   return this.http.get<Patient[]>(this.baseUrl+"/vaa/"+did);
// }
// findDischargedPatientById(did:any):Observable <Patient[]> {
//   return this.http.get<Patient[]>(this.baseUrl+"/vpd/"+did);
// }
// DischargedPatientById(did:any):Observable <Patient[]> {
//   return this.http.get<Patient[]>(this.baseUrl+"/dpd/"+did);
// }
}
