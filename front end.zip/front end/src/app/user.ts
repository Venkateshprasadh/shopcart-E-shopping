export class user {
    constructor(
        public email:string,
        public password:string,
        public subscription:string
        ){}
}